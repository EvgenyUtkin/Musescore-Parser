from PyQt5.QtWidgets import QMainWindow, QApplication, QTabWidget, QLabel, QTextEdit, QPushButton, QLineEdit, \
    QTableWidget, QTableWidgetItem, QComboBox, QWidget, QListWidget, QVBoxLayout, QAbstractItemView
from PyQt5 import uic
from PyQt5.QtGui import QPixmap, QFont, QColor, QPalette
from PyQt5 import QtCore
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
import requests
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF
from PyPDF2 import PdfMerger
import sys
from PIL import Image
from webdriver_manager.firefox import GeckoDriverManager

class UI(QMainWindow):
    def __init__(self):
        super(UI, self).__init__()

        # Load the ui file
        uic.loadUi("ui/ui.ui", self)

        # Connect widgets
        self.label = self.findChild(QLabel, "label")
        self.link_textEdit = self.findChild(QTextEdit, "link_textEdit")
        self.fname_textEdit = self.findChild(QTextEdit, "fname_textEdit")
        self.download_pushButton = self.findChild(QPushButton, "download_pushButton")

        # Connect pushbuttons
        self.download_pushButton.clicked.connect(lambda: self.download_pushButton_clicked())

        self.show()

    def download_pushButton_clicked(self):
        LINK = self.link_textEdit.toPlainText().split('\n')[0]
        FILENAME = self.fname_textEdit.toPlainText()
        self.label.setText("В процессе...")
        time.sleep(0.5)
        try:
            driver = webdriver.Firefox(executable_path=GeckoDriverManager().install())
            driver.get(LINK)
            html = driver.page_source
            bs = BeautifulSoup(html, "lxml")

            DIVS = bs.find_all("div", {'class': "EEnGW"})
            TOTAL_PAGES = len(DIVS)

            SCROLL_PAUSE_TIME = 0.2
            SRC = set()
            PAGE_NUM = 1
            while True:
                # Wait to load page
                time.sleep(SCROLL_PAUSE_TIME)

                body = driver.find_element(By.CSS_SELECTOR, 'body')
                body.click()
                if len(SRC) == PAGE_NUM:
                    body.send_keys(Keys.ARROW_RIGHT)
                    PAGE_NUM += 1

                html = driver.page_source

                bs = BeautifulSoup(html, "lxml")
                imgs = bs.find_all("img", {'class': "KfFlO"})

                for img in imgs:
                    try:
                        alt = img['alt']
                        pages = alt.split('–')[-1]
                        n = pages.split()[0]
                        SRC.add((int(n), img['src']))
                    except:
                        pass
                if len(SRC) == TOTAL_PAGES:
                    break
            driver.close()

            merger = PdfMerger()

            for el in sorted(list(SRC)):
                fname = el[1].split('/')[-1]
                fname = fname.replace('@', '?')
                fname = fname.split('?')[0]
                ftype = fname.split('.')[-1]
                if ftype == 'svg':
                    content = requests.get(el[1]).text
                    with open(f'tmp/{el[0]}.svg', 'w', encoding='utf8') as file:
                        file.write(content)
                    drawing = svg2rlg(f'tmp/{el[0]}.svg')
                    renderPDF.drawToFile(drawing, f'tmp/{el[0]}.pdf')
                elif ftype == 'png':
                    content = requests.get(el[1]).content
                    with open(f'tmp/{el[0]}.png', 'wb') as file:
                        file.write(content)
                    image = Image.open(f'tmp/{el[0]}.png')
                    image.save(f'tmp/{el[0]}.pdf', "PDF", resolution=100.0, save_all=True)
                merger.append(f'tmp/{el[0]}.pdf')

            merger.write(f"saves/{FILENAME}.pdf")
            merger.close()

            self.label.setText(f"Успешно! Ноты здесь: saves/{FILENAME}.pdf")
        except Exception as err:
            self.label.setText(f"{type(err).__name__} was raised: {err}")





app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()
